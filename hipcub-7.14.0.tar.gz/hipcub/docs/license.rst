License
=======

.. include:: ../LICENSE.txt
